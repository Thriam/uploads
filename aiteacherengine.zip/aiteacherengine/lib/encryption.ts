import * as CryptoJS from 'crypto-js';
import env from './env';

const secretKey = env.ENCRYPTION_KEY;

if (!secretKey) {
  throw new Error('ENCRYPTION_KEY is not defined in the environment variables.');
}

/**
 * Encrypts a given text using AES.
 * @param text The text to encrypt.
 * @returns The encrypted string.
 */
export function encrypt(text: string): string {
  if (!text) return text;
  return CryptoJS.AES.encrypt(text, secretKey).toString();
}

/**
 * Decrypts a given AES-encrypted string.
 * @param ciphertext The encrypted text to decrypt.
 * @returns The original, decrypted string.
 */
export function decrypt(ciphertext: string): string {
  if (!ciphertext) return ciphertext;
  const bytes = CryptoJS.AES.decrypt(ciphertext, secretKey);
  return bytes.toString(CryptoJS.enc.Utf8);
}
