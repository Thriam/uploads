import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import crypto from "crypto";

const s3Client = new S3Client({
  region: process.env.AWS_S3_REGION!,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
});

const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME!;

/**
 * Generates a presigned URL for uploading a file to S3.
 * @param key The key (path) for the object in S3.
 * @param contentType The MIME type of the file.
 * @returns The presigned URL.
 */
export async function getPresignedUploadUrl(key: string, contentType: string): Promise<string> {
  const command = new PutObjectCommand({
    Bucket: BUCKET_NAME,
    Key: key,
    ContentType: contentType,
  });
  return getSignedUrl(s3Client, command, { expiresIn: 3600 });
}

/**
 * Uploads a file buffer to AWS S3.
 * @param buffer The file content as a Buffer.
 * @param key The destination key (path/filename) in the S3 bucket.
 * @param contentType The MIME type of the file.
 * @returns The public URL of the uploaded file.
 */
export async function uploadToS3(buffer: Buffer, key: string, contentType: string): Promise<string> {
    const command = new PutObjectCommand({
        Bucket: BUCKET_NAME,
        Key: key,
        Body: buffer,
        ContentType: contentType,
    });

    try {
        await s3Client.send(command);
        // Construct the public URL. This assumes the bucket is public or you have a CDN.
        // For private buckets, you'd generate a presigned GET URL instead.
        const url = `https://${BUCKET_NAME}.s3.${process.env.AWS_S3_REGION}.amazonaws.com/${key}`;
        return url;
    } catch (error) {
        console.error("Error uploading to S3:", error);
        throw new Error("Failed to upload file to S3.");
    }
}

/**
 * Generates a random file name.
 * @param bytes The number of random bytes to generate.
 * @returns A random hex string.
 */
export const randomImageName = (bytes = 16) => crypto.randomBytes(bytes).toString("hex");
