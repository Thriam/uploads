import { cleanEnv, str, url } from 'envalid';

const env = cleanEnv(process.env, {
  DATABASE_URL:           url(),
  REDIS_HOST:             str({ default: 'localhost' }),
  REDIS_PORT:             str({ default: '6379' }),
  REDIS_PASSWORD:         str({ default: undefined }),
  
  // A 32-byte secret key for encrypting sensitive data at rest.
  // Generate one with: require('crypto').randomBytes(32).toString('hex')
  ENCRYPTION_KEY:         str(),

  CRON_SECRET:            str(),
  NEXT_PUBLIC_APP_URL:    url({ devDefault: 'http://localhost:3000' }),

  // Optional API Keys (can be set by user in the dashboard)
  OPENAI_API_KEY:         str({ default: undefined }),
  ELEVENLABS_API_KEY:     str({ default: undefined }),
  ELEVENLABS_VOICE_ID:    str({ default: undefined }),
  HEYGEN_API_KEY:         str({ default: undefined }),
  META_ACCESS_TOKEN:      str({ default: undefined }),
  INSTAGRAM_BUSINESS_ACCOUNT_ID: str({ default: undefined }),
  FACEBOOK_PAGE_ID:       str({ default: undefined }),
});

export default env;
