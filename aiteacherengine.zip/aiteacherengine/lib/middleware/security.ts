import { NextApiRequest, NextApiResponse } from 'next';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import cors from 'cors';
import logger from '../logger';

type NextApiHandler = (req: NextApiRequest, res: NextApiResponse) => Promise<void>;

// Helper to run middleware
const runMiddleware = (req: NextApiRequest, res: NextApiResponse, fn: Function) => {
  return new Promise((resolve, reject) => {
    fn(req, res, (result: any) => {
      if (result instanceof Error) {
        return reject(result);
      }
      return resolve(result);
    });
  });
};

// Rate Limiter: 100 requests per 15 minutes per IP
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: any, res: any) => {
    logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
    res.status(429).json({ error: 'Too many requests, please try again later.' });
  },
});

// CORS configuration
const corsMiddleware = cors({
  origin: process.env.NEXT_PUBLIC_APP_URL, // Only allow requests from your app's origin
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  credentials: true,
});

export function withSecurity(handler: NextApiHandler): NextApiHandler {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    try {
      // Apply security middleware
      await runMiddleware(req, res, helmet());
      await runMiddleware(req, res, corsMiddleware);
      await runMiddleware(req, res, limiter);

      // Proceed to the actual handler
      return handler(req, res);
    } catch (error) {
      logger.error('Error in security middleware', { error });
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
}
