import { NextApiRequest, NextApiResponse } from 'next';
import { ZodSchema, ZodError } from 'zod';
import logger from '../logger';

type NextApiHandler = (req: NextApiRequest, res: NextApiResponse) => Promise<void>;

export function withValidation(schema: ZodSchema, handler: NextApiHandler): NextApiHandler {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    try {
      schema.parse(req.body);
      return handler(req, res);
    } catch (error) {
      if (error instanceof ZodError) {
        logger.warn('Invalid input detected', { errors: error.errors });
        return res.status(400).json({ error: 'Invalid input.', details: error.errors });
      }
      // For other errors, pass them to a generic error handler
      return errorHandler(error, req, res);
    }
  };
}

export function errorHandler(err: any, req: NextApiRequest, res: NextApiResponse) {
  logger.error('An unexpected error occurred', {
    error: err.message,
    stack: err.stack,
    path: req.url,
  });

  res.status(500).json({ error: 'An internal server error occurred.' });
}
