import { useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import axios from 'axios';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';

export default function DashboardPage() {
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { token } = useAuth();

  const handleGenerateVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic) {
      toast.error('Please enter a topic.');
      return;
    }
    setIsLoading(true);
    try {
      await axios.post('/api/videos', { topic }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Video generation job has been started!');
      setTopic('');
    } catch (error) {
      console.error(error);
      toast.error('Failed to start video generation.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="px-4 py-6 sm:px-0">
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
        <div className="mt-6 bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
          <h2 className="text-lg leading-6 font-medium text-gray-900">Generate a New Video</h2>
          <form className="mt-5 sm:flex sm:items-center" onSubmit={handleGenerateVideo}>
            <div className="w-full sm:max-w-xs">
              <label htmlFor="topic" className="sr-only">Topic</label>
              <input
                type="text"
                name="topic"
                id="topic"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                placeholder="e.g., 'The History of Python'"
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="mt-3 w-full inline-flex items-center justify-center px-4 py-2 border border-transparent shadow-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm disabled:opacity-50"
            >
              {isLoading ? 'Starting...' : 'Generate Video'}
            </button>
          </form>
        </div>
      </div>
    </DashboardLayout>
  );
}
