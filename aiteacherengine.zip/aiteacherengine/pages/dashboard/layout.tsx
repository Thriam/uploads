import { ReactNode, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../context/AuthContext';
import Link from 'next/link';

interface DashboardLayoutProps {
  children: ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const { isAuthenticated, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, router]);

  if (!isAuthenticated) {
    return null; // or a loading spinner
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="fixed inset-y-0 left-0 w-64 bg-gray-900 text-white">
        <div className="p-6">
          <h1 className="text-xl font-bold">AI Teacher</h1>
        </div>
        <nav className="mt-6">
          <Link href="/dashboard" className="block px-6 py-3 hover:bg-gray-800">
            Dashboard
          </Link>
          <Link href="/dashboard/videos" className="block px-6 py-3 hover:bg-gray-800">
            Videos
          </Link>
          <Link href="/dashboard/settings" className="block px-6 py-3 hover:bg-gray-800">
            Settings
          </Link>
        </nav>
        <div className="absolute bottom-0 w-full p-6">
          <button
            onClick={logout}
            className="w-full py-2 px-4 bg-gray-800 hover:bg-gray-700 rounded-md"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="ml-64 p-8">
        {children}
      </div>
    </div>
  );
}
