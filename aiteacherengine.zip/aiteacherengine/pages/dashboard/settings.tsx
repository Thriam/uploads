import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import axios from 'axios';
import toast from 'react-hot-toast';
import DashboardLayout from './layout';

interface Settings {
  openaiApiKey: string;
  elevenLabsApiKey: string;
  heygenApiKey: string;
  metaAccessToken: string;
  avatarPhotoUrl: string;
  heygenAvatarId: string;
  dailyPostTime: string;
  topicCategory: string;
  autoPost: boolean;
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings>({
    openaiApiKey: '',
    elevenLabsApiKey: '',
    heygenApiKey: '',
    metaAccessToken: '',
    avatarPhotoUrl: '',
    heygenAvatarId: '',
    dailyPostTime: '10:00',
    topicCategory: 'General Knowledge',
    autoPost: false,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const { token } = useAuth();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await axios.get('/api/settings', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.data) {
        setSettings({ ...settings, ...response.data });
      }
    } catch (error) {
      console.error('Failed to fetch settings');
    } finally {
      setIsFetching(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await axios.put('/api/settings', settings, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Settings saved successfully!');
    } catch (error) {
      console.error(error);
      toast.error('Failed to save settings');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (field: keyof Settings, value: string | boolean) => {
    setSettings((prev) => ({ ...prev, [field]: value }));
  };

  if (isFetching) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-64">
          <div className="text-gray-500">Loading...</div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Settings</h1>

        <form onSubmit={handleSave} className="space-y-8">
          {/* API Keys Section */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">API Keys</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  OpenAI API Key
                </label>
                <input
                  type="password"
                  value={settings.openaiApiKey}
                  onChange={(e) => handleChange('openaiApiKey', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="sk-..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  ElevenLabs API Key
                </label>
                <input
                  type="password"
                  value={settings.elevenLabsApiKey}
                  onChange={(e) => handleChange('elevenLabsApiKey', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  HeyGen API Key
                </label>
                <input
                  type="password"
                  value={settings.heygenApiKey}
                  onChange={(e) => handleChange('heygenApiKey', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Meta Access Token
                </label>
                <input
                  type="password"
                  value={settings.metaAccessToken}
                  onChange={(e) => handleChange('metaAccessToken', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="..."
                />
              </div>
            </div>
          </div>

          {/* Avatar Section */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Avatar Configuration</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Avatar Photo URL
                </label>
                <input
                  type="url"
                  value={settings.avatarPhotoUrl}
                  onChange={(e) => handleChange('avatarPhotoUrl', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="https://..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  HeyGen Avatar ID
                </label>
                <input
                  type="text"
                  value={settings.heygenAvatarId}
                  onChange={(e) => handleChange('heygenAvatarId', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Avatar ID from HeyGen"
                />
              </div>
            </div>
          </div>

          {/* Automation Section */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Automation</h2>
            <div className="space-y-4">
              <div className="flex items-center">
                <input
                  id="autoPost"
                  type="checkbox"
                  checked={settings.autoPost}
                  onChange={(e) => handleChange('autoPost', e.target.checked)}
                  className="h-4 w-4 text-indigo-600 border-gray-300 rounded"
                />
                <label htmlFor="autoPost" className="ml-2 block text-sm text-gray-900">
                  Auto-post to social media when video is ready
                </label>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Daily Post Time (UTC)
                </label>
                <input
                  type="time"
                  value={settings.dailyPostTime}
                  onChange={(e) => handleChange('dailyPostTime', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Topic Category
                </label>
                <select
                  value={settings.topicCategory}
                  onChange={(e) => handleChange('topicCategory', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="General Knowledge">General Knowledge</option>
                  <option value="Technology">Technology</option>
                  <option value="Science">Science</option>
                  <option value="History">History</option>
                  <option value="Health">Health</option>
                  <option value="Business">Business</option>
                </select>
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-md disabled:opacity-50"
          >
            {isLoading ? 'Saving...' : 'Save Settings'}
          </button>
        </form>
      </div>
    </DashboardLayout>
  );
}
