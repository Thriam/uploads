import { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient, VideoStatus } from '@prisma/client';
import { videoQueue } from '../../queues/videoQueue';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Secure the endpoint with a secret key from environment variables
  const cronSecret = process.env.CRON_SECRET;
  const authHeader = req.headers.authorization;

  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    console.warn('Unauthorized attempt to access cron endpoint.');
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'POST') {
    try {
      console.log('Cron job triggered: Searching for users with auto-post enabled.');

      // Find all users who have auto-posting enabled in their schedule
      const usersToProcess = await prisma.user.findMany({
        where: {
          schedule: {
            autoPost: true,
          },
        },
        include: {
          schedule: true, // Include schedule to get the topic category
        },
      });

      if (usersToProcess.length === 0) {
        console.log('Cron job finished: No users found with auto-post enabled.');
        return res.status(200).json({ message: 'No users to process.' });
      }

      console.log(`Found ${usersToProcess.length} user(s) to process.`);

      // For each user, create a new video record and add a job to the queue
      for (const user of usersToProcess) {
        if (user.schedule) {
          // A simple topic for demonstration purposes
          const topic = `A new video about ${user.schedule.topicCategory}`;
          
          const newVideo = await prisma.video.create({
            data: {
              userId: user.id,
              topic: topic,
              status: VideoStatus.PENDING,
            },
          });

          // Add a job to the video generation queue
          await videoQueue.add('generate-video', { videoId: newVideo.id });
          console.log(`Successfully queued video generation for user ${user.id} (Video ID: ${newVideo.id})`);
        }
      }

      res.status(200).json({ message: `Successfully queued ${usersToProcess.length} video generation jobs.` });
    } catch (error) {
      console.error('Error during cron job execution:', error);
      res.status(500).json({ error: 'Internal Server Error during cron execution.' });
    }
  } else {
    res.setHeader('Allow', 'POST');
    res.status(405).end('Method Not Allowed');
  }
}
