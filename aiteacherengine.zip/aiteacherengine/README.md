# AI Teacher Engine

We have built:

*   A **Prisma schema** for your database.
*   **Backend services** to interact with OpenAI, ElevenLabs, HeyGen, Meta, and AWS S3.
*   A **BullMQ queue system** with a dedicated worker to handle the video generation and posting process asynchronously.
*   Secure **API routes** for authentication, settings management, video processing, and a cron job trigger.
*   A **Next.js frontend** with TailwindCSS, including a protected admin dashboard to manage the application.
*   **Production-grade security** including environment validation, API key encryption, logging, and security middleware.

npm install express-rate-limit helmet cors crypto-js zod winston envalid
npm install --save-dev @types/crypto-js

Your next steps are to bring the application to life by following the setup instructions I provided earlier:

1.  **Install Dependencies**: `npm install`
2.  **Configure Environment**: Create and fill out your `.env` file.
3.  **Migrate Database**: `npx prisma migrate dev --name init`
4.  **Run the Worker**: `npx ts-node-dev workers/videoWorker.ts`
5.  **Run the App**: `npm run dev`
6. `npx prisma migrate dev --name add_video_caption`
7. `npx prisma migrate dev --name redesign-schema`

Once these steps are completed, you will have a running version of your "AI Teacher Engine" on your local machine.

---

## Project Structure

```
/aiteacherengine
|
|-- /app/                           # Next.js App Router: Routes and Pages
|   |-- /api/                       # Backend API Routes
|   |   |-- /auth/
|   |   |   `-- [...nextauth]/route.ts # Authentication logic (e.g., NextAuth.js)
|   |   |-- /cron/
|   |   |   `-- route.ts            # Endpoint for cron job to trigger video generation
|   |   |-- /videos/
|   |   |   `-- route.ts            # API for fetching/managing videos
|   |   `-- /webhooks/
|   |       |-- /heygen/route.ts    # Webhook for HeyGen video status updates
|   |       `-- /stripe/route.ts    # (Future) Webhook for payment processing
|   |
|   |-- /dashboard/                 # Frontend Pages for the Admin Dashboard
|   |   |-- /avatars/page.tsx       # UI for avatar management
|   |   |-- /keys/page.tsx          # UI for managing API keys
|   |   |-- /settings/page.tsx      # UI for app settings (schedule, etc.)
|   |   |-- /videos/page.tsx        # UI for video history
|   |   |-- layout.tsx              # Shared layout for all dashboard pages
|   |   `-- page.tsx                # Main dashboard overview page
|   |
|   |-- favicon.ico                 # Application icon
|   |-- globals.css                 # Global CSS styles
|   `-- layout.tsx                  # Root layout for the entire application
|
|-- /components/                    # Reusable React Components
|   |-- /layout/
|   |   |-- DashboardLayout.tsx     # Main dashboard layout (Sidebar + Header)
|   |   |-- Header.tsx              # Top header component
|   |   `-- Sidebar.tsx             # Side navigation bar
|   |
|   |-- /ui/                        # Small, generic UI components (shadcn/ui style)
|   |   |-- Badge.tsx
|   |   |-- Button.tsx
|   |   |-- Card.tsx
|   |   |-- Input.tsx
|   |   |-- Label.tsx
|   |   |-- Switch.tsx
|   |   `-- Table.tsx
|   |
|   `-- /shared/
|       `-- PageTitle.tsx           # Reusable component for page headings
|
|-- /lib/                           # Shared utilities, helpers, and configurations
|   |-- /middleware/
|   |   |-- security.ts             # Security middleware (Helmet, CORS, Rate Limit)
|   |   `-- validation.ts           # Zod validation and error handling middleware
|   |
|   |-- /prisma/
|   |   `-- client.ts               # Singleton Prisma client instance
|   |
|   |-- encryption.ts               # Service for encrypting/decrypting data
|   |-- env.ts                      # Environment variable validation (envalid)
|   |-- logger.ts                   # Winston logger configuration
|   `-- utils.ts                    # General utility functions (e.g., cn for Tailwind)
|
|-- /prisma/                        # Database schema and migrations
|   |-- /migrations/                # Database migration history
|   |-- schema.prisma               # The heart of your database schema
|   `-- seed.ts                     # (Optional) Script to seed database with initial data
|
|-- /public/                        # Static assets (images, fonts, etc.)
|   |-- /images/
|   `-- /vectors/
|
|-- /queues/                        # BullMQ job queue definitions
|   `-- videoQueue.ts               # Queue for video generation jobs
|
|-- /services/                      # Modules for interacting with third-party APIs
|   |-- /ai/
|   |   `-- openai.ts               # OpenAI API service (script generation)
|   |-- /social/
|   |   `-- meta.ts                 # Meta API service (Instagram/Facebook posting)
|   |-- /storage/
|   |   `-- s3.ts                   # AWS S3 service (file uploads)
|   `-- /video/
|       |-- elevenlabs.ts           # ElevenLabs API service (voice generation)
|       `-- heygen.ts               # HeyGen API service (avatar video generation)
|
|-- /workers/                       # Background job processors
|   `-- videoWorker.ts              # BullMQ worker for video generation jobs
|
|-- .env.example                    # Example environment variables
|-- .eslintrc.json                  # ESLint configuration
|-- .gitignore                      # Git ignore file
|-- next.config.mjs                  # Next.js configuration
|-- package.json                    # Project dependencies and scripts
|-- postcss.config.js               # PostCSS configuration (for Tailwind)
|-- README.md                       # Project documentation
|-- tailwind.config.ts              # Tailwind CSS configuration
`-- tsconfig.json                   # TypeScript configuration
```

### Why This Structure Works

* **Clear Separation of Concerns:**
  * **`app`**: Handles routing and the UI layer.
  * **`components`**: Contains all reusable UI elements, keeping your pages clean.
  * **`lib`**: Holds shared business logic and configuration, preventing code duplication.
  * **`services`**: Isolates all third-party API communication. If you need to change your video provider from HeyGen to something else, you only need to update the file in `services/video`.
  * **`queues` & `workers`**: Decouples job definitions from their execution logic, which is excellent for scalability and maintenance.

* **Scalability:** This structure is easy to expand. Need a new API? Add a file in `services` and a route in `app/api`. Need a new dashboard page? Add a folder in `app/dashboard`.

* **Follows Conventions:** It adheres to the standard conventions of the Next.js App Router, making it intuitive for any developer familiar with the ecosystem.

* **Backend vs. Frontend:**
  * **Backend:** Your backend lives primarily in `app/api`, `lib`, `services`, `queues`, and `workers`.
  * **Frontend:** Your frontend lives in `app/dashboard` (and other page routes) and `components`.

---

## Deployment Guide: AI Teacher Engine on Render

This guide covers deploying your Next.js application, a PostgreSQL database, a Redis instance, and a cron job on Render.

### Part 1: Prerequisites - AWS S3 Bucket

Before deploying to Render, you need a place to store generated media. AWS S3 is the perfect solution.

1. **Create an S3 Bucket:**
   * Log in to your AWS Console and navigate to the S3 service.
   * Create a new bucket. Give it a unique name (e.g., `ai-teacher-engine-media-yourname`) and choose a region (e.g., `us-east-1`).
   * **Important:** Under "Block Public Access settings for this bucket," uncheck "Block all public access" and acknowledge the warning. This is necessary for HeyGen and social media platforms to access the generated voice and video files via their public URLs.

2. **Create an IAM User:**
   * Navigate to the IAM service in AWS.
   * Create a new user. Give it a name (e.g., `ai-teacher-engine-s3-user`) and select "Access key - Programmatic access" as the credential type.
   * On the permissions screen, select "Attach existing policies directly" and then "Create policy."
   * In the JSON editor, paste the following policy. **Remember to replace `your-bucket-name` with the actual name of your S3 bucket.**

```
json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:PutObjectAcl"
            ],
            "Resource": "arn:aws:s3:::your-bucket-name/*"
        }
    ]
}
```

   * Save the policy, go back to the user creation flow, attach your new policy, and complete the process.
   * **Crucial:** On the final screen, copy and securely store the **Access key ID** and **Secret access key**. You will need these for your environment variables.

### Part 2: Render Setup - Database & Redis

1. **Create a PostgreSQL Database:**
   * From your Render Dashboard, click **New +** > **PostgreSQL**.
   * Give it a name (e.g., `ai-teacher-db`), select a region (choose the same for all your services), and click **Create Database**.
   * Render will provide you with a **`DATABASE_URL`** (Internal Connection String). You will use this later.

2. **Create a Redis Instance:**
   * From your Render Dashboard, click **New +** > **Redis**.
   * Give it a name (e.g., `ai-teacher-redis`), select the same region, and click **Create Redis**.
   * Render will provide you with the `REDIS_HOST`, `REDIS_PORT`, and `REDIS_PASSWORD`.

### Part 3: Deploying the Application (Web Service)

This is your main Next.js application.

1. **Create a New Web Service:**
   * From your Render Dashboard, click **New +** > **Web Service**.
   * Connect your GitHub/GitLab repository where the code is hosted.
   * In the settings:
     * **Name:** `ai-teacher-engine` (or your preferred name).
     * **Root Directory:** `aiteacherengine` (since all your code is inside this folder).
     * **Environment:** `Node`.
     * **Region:** The same region as your database and Redis.
     * **Branch:** `main` (or your production branch).
     * **Build Command:** This is critical. It ensures Prisma is ready and the app is built for production.

```
bash
npm install && npx prisma generate && npx prisma migrate deploy && npm run build
```

     * **Start Command:**

```
bash
npm start
```

     * **Instance Type:** Start with `Starter` and scale up as needed.

2. **Add Environment Variables:**
   * Go to the "Environment" tab for your new Web Service.
   * Click "Add Environment Group" and create a group (e.g., `ai-teacher-prod-vars`). This lets you share variables with your other services.
   * Add all the required environment variables from the list in **Part 5**.

### Part 4: Deploying the Worker & Cron Job

Your application has two background components: the BullMQ worker and the cron job trigger.

1. **Deploy the Background Worker:**
   * The worker must run as a separate process to handle background jobs without blocking the web server.
   * First, add a worker start script to your `package.json`:

```
json
"scripts": {
  "dev": "next dev",
  "build": "next build",
  "start": "next start",
  "lint": "next lint",
  "start-worker": "node -r ts-node/register/transpile-only ./workers/videoWorker.ts"
},
```

   * Now, create a new service on Render: **New +** > **Background Worker**.
   * **Settings:**
     * **Name:** `ai-teacher-worker`.
     * **Root Directory:** `aiteacherengine`.
     * **Environment:** `Node`.
     * **Region:** Same as your other services.
     * **Branch:** `main`.
     * **Start Command:** `npm run start-worker`.
   * **Environment:** In the "Environment" tab, link the same environment group (`ai-teacher-prod-vars`) you created for the web service.

2. **Create the Cron Job:**
   * This service will trigger your `/api/cron` endpoint on a schedule.
   * From your Render Dashboard, click **New +** > **Cron Job**.
   * **Settings:**
     * **Name:** `daily-video-trigger`.
     * **Schedule:** `0 10 * * *` (This runs at 10:00 AM UTC every day. You can adjust this).
     * **Command:**

```
bash
curl -X POST -H "Authorization: Bearer $CRON_SECRET" https://ai-teacher-engine.onrender.com/api/cron
```

       (Replace `ai-teacher-engine.onrender.com` with your Web Service's public URL).
   * **Environment:** Link the same environment group again.

### Part 5: Production Environment Variables

Add these to your shared environment group on Render.

| Variable | Value | Source |
| ------------------------------- | ------------------------------------------------------------------ | ------------------------------------ |
| `NODE_ENV` | `production` | Static Value |
| `DATABASE_URL` | `postgres://...` | From your Render PostgreSQL Service |
| `REDIS_HOST` | `red-c...` | From your Render Redis Service |
| `REDIS_PORT` | `6379` | From your Render Redis Service |
| `REDIS_PASSWORD` | `your-redis-password` | From your Render Redis Service |
| `ENCRYPTION_KEY` | A 64-character hex string | Generate one locally and paste it |
| `CRON_SECRET` | A long, random, secret string | Generate one yourself |
| `NEXT_PUBLIC_APP_URL` | `https://your-app-name.onrender.com` | Your Render Web Service URL |
| `AWS_ACCESS_KEY_ID` | `AKIA...` | From your AWS IAM User (Part 1) |
| `AWS_SECRET_ACCESS_KEY` | `your-aws-secret-key` | From your AWS IAM User (Part 1) |
| `AWS_S3_BUCKET_NAME` | `ai-teacher-engine-media...` | Your S3 Bucket Name (Part 1) |
| `AWS_REGION` | `us-east-1` | Your S3 Bucket Region (Part 1) |
| `OPENAI_API_KEY` | `sk-...` | Your OpenAI Account |
| `ELEVENLABS_API_KEY` | `your-elevenlabs-key` | Your ElevenLabs Account |
| `ELEVENLABS_VOICE_ID` | `your-elevenlabs-voice-id` | Your ElevenLabs Account |
| `HEYGEN_API_KEY` | `your-heygen-key` | Your HeyGen Account |
| `META_ACCESS_TOKEN` | `your-long-lived-token` | Your Meta Developer Account |
| `INSTAGRAM_BUSINESS_ACCOUNT_ID` | `178...` | Your Instagram Account |
| `FACEBOOK_PAGE_ID` | `100...` | Your Facebook Page |

### Part 6: Scaling Advice

* **Start Simple:** The `Starter` plans on Render are powerful. Monitor your application's response time and resource usage in the Render dashboard.
* **Vertical Scaling:** If your app or worker becomes slow, the first step is to scale up vertically. Go to your service's "Scaling" tab and choose a larger instance type (e.g., `Standard`). This gives you more RAM and CPU.
* **Horizontal Scaling:** If one instance isn't enough, you can scale horizontally by increasing the number of instances. Your application is stateless (state is in Redis/Postgres), so it's safe to scale this way. Render will automatically load-balance traffic between your instances.
* **Separate Workers:** For very high-demand applications, you could create different worker services for different queues (e.g., a high-priority queue for user-facing jobs and a low-priority one for background tasks), each with its own scaling rules.

---

The complete automation system is now in place. Here's a quick summary of what we've built:

pages/api/cron.ts: A secure endpoint that finds users with auto-posting enabled and queues up video generation jobs for them.
queues/videoQueue.ts: A BullMQ queue configured with an exponential backoff retry strategy to handle failures gracefully.
workers/videoWorker.ts: A robust worker that processes jobs from the queue, orchestrating the entire video creation pipeline from script generation to social media posting, with detailed status updates and error handling.
To run this system, you will need to:

Start the worker: In your terminal, run a script to import and start the worker. This is typically done in a separate process from your main Next.js application.
Set up a cron job: Configure a service (like Vercel Cron Jobs, GitHub Actions, or a traditional cron daemon) to send a POST request to your /api/cron endpoint at your desired schedule. Remember to include the Authorization: Bearer YOUR_CRON_SECRET header.
