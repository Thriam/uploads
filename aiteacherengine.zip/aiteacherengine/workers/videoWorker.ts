import { Worker, Job } from 'bullmq';
import { PrismaClient, VideoStatus } from '@prisma/client';
import { redisConnection } from '../lib/redis';
import { generateScript } from '../services/ai/openai';
import { generateVoice } from '../services/video/elevenlabs';
import { generateAvatarVideo } from '../services/video/heygen';
import { postToInstagram, postToFacebook } from '../services/social/meta';

const prisma = new PrismaClient();

// Helper function to update video status and log it
const updateStatus = async (videoId: string, status: VideoStatus, errorMessage?: string) => {
  console.log(`Updating video ${videoId} to status: ${status}`);
  if (errorMessage) {
    console.error(`Error for video ${videoId}: ${errorMessage}`);
  }
  return await prisma.video.update({
    where: { id: videoId },
    data: { status, errorMessage },
  });
};

const videoWorker = new Worker(
  'video-generation',
  async (job: Job) => {
    const { videoId } = job.data;
    console.log(`Processing video generation job for video ID: ${videoId}`);

    try {
      // Fetch all necessary data in one go based on the new schema
      const video = await prisma.video.findUnique({
        where: { id: videoId },
        include: {
          user: {
            include: {
              apiKeys: true,
              schedule: true,
              avatars: {
                where: { isActive: true },
                take: 1,
              },
            },
          },
        },
      });

      if (!video || !video.user || !video.user.apiKeys || !video.user.schedule || video.user.avatars.length === 0) {
        throw new Error(`Could not find complete user data, API keys, schedule, or active avatar for video ${videoId}`);
      }

      const { user } = video;
      const { apiKeys, schedule } = user;
      const activeAvatar = user.avatars[0];

      // Temporarily set environment variables for the API clients for this job's scope
      process.env.OPENAI_API_KEY = apiKeys.openaiApiKey;
      process.env.ELEVENLABS_API_KEY = apiKeys.elevenlabsApiKey;
      process.env.ELEVENLABS_VOICE_ID = apiKeys.elevenlabsVoiceId;
      process.env.HEYGEN_API_KEY = apiKeys.heygenApiKey;
      process.env.META_ACCESS_TOKEN = apiKeys.metaAccessToken;
      process.env.INSTAGRAM_BUSINESS_ACCOUNT_ID = apiKeys.instagramBusinessAccountId;
      process.env.FACEBOOK_PAGE_ID = apiKeys.facebookPageId;

      // 1. Generate Script
      await updateStatus(videoId, VideoStatus.GENERATING_SCRIPT);
      const { hook, script, caption } = await generateScript(video.topic, schedule.topicCategory);
      await prisma.video.update({ where: { id: videoId }, data: { hook, script, caption } });

      // 2. Generate Voice
      await updateStatus(videoId, VideoStatus.GENERATING_VOICE);
      const fullScript = `${hook}\n\n${script}`;
      const localVoiceUrl = await generateVoice(fullScript);
      const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
      const voiceUrl = new URL(localVoiceUrl, baseUrl).toString();
      await prisma.video.update({ where: { id: videoId }, data: { voiceUrl } });

      // 3. Generate Video
      await updateStatus(videoId, VideoStatus.GENERATING_VIDEO);
      const videoUrl = await generateAvatarVideo(fullScript, voiceUrl, activeAvatar.heygenAvatarId);
      await prisma.video.update({ where: { id: videoId }, data: { videoUrl } });

      // 4. Post to Social Media
      await updateStatus(videoId, VideoStatus.POSTING);
      const postPromises = [];
      if (apiKeys.instagramBusinessAccountId) {
        postPromises.push(
          postToInstagram(videoUrl, caption || video.topic)
            .then(postId => prisma.post.create({ data: { videoId, platform: 'INSTAGRAM', postId } }))
            .catch(e => console.error('Instagram post failed:', e))
        );
      }
      if (apiKeys.facebookPageId) {
        postPromises.push(
          postToFacebook(videoUrl, caption || video.topic)
            .then(postId => prisma.post.create({ data: { videoId, platform: 'FACEBOOK', postId } }))
            .catch(e => console.error('Facebook post failed:', e))
        );
      }
      await Promise.all(postPromises);

      // 5. Mark as complete
      await updateStatus(videoId, VideoStatus.COMPLETED);
      console.log(`Successfully completed video generation and posting for video ID: ${videoId}`);

    } catch (error) {
      console.error(`Job for video ${videoId} failed:`, error);
      await updateStatus(videoId, VideoStatus.FAILED, error.message);
      throw error;
    }
  },
  { connection: redisConnection }
);

videoWorker.on('failed', (job, err) => {
  console.error(`Job ${job?.id} failed with error: ${err.message}`);
});

export default videoWorker;