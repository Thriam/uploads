import { Button } from '../ui/button';

export function Header() {
  return (
    <header className="flex h-16 items-center justify-between border-b border-gray-200 bg-white px-6 dark:border-gray-800 dark:bg-gray-950">
      <div className="flex items-center">
        {/* Can add breadcrumbs or page title here */}
        <h1 className="text-lg font-semibold">Dashboard</h1>
      </div>
      <div className="flex items-center gap-4">
        {/* Placeholder for user menu */}
        <Button variant="outline" size="sm">
          Logout
        </Button>
      </div>
    </header>
  );
}
