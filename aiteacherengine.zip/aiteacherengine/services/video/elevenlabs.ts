import ElevenLabs from 'elevenlabs';
import fs from 'fs';
import path from 'path';
import { Writable } from 'stream';
import crypto from 'crypto';

const elevenlabs = new ElevenLabs({
  apiKey: process.env.ELEVENLABS_API_KEY,
});

/**
 * Generates voice from text using ElevenLabs API, saves it locally, and returns a public URL.
 * @param script The text to convert to speech.
 * @param voiceId The ID of the cloned voice to use. Defaults to the ID in the environment variables.
 * @returns A promise that resolves to the public URL of the saved MP3 file.
 */
export async function generateVoice(script: string, voiceId?: string): Promise<string> {
  try {
    const voiceToUse = voiceId || process.env.ELEVENLABS_VOICE_ID;
    if (!voiceToUse) {
      throw new Error('ElevenLabs Voice ID is not specified in parameters or environment variables.');
    }

    const audioStream = await elevenlabs.generate({
      voice: voiceToUse,
      text: script,
      model_id: 'eleven_multilingual_v2',
    });

    if (!audioStream) {
      throw new Error('Failed to generate voice stream from ElevenLabs.');
    }

    const fileName = `${crypto.randomBytes(16).toString('hex')}.mp3`;
    const dirPath = path.join(process.cwd(), 'public', 'audio');
    const filePath = path.join(dirPath, fileName);

    // Ensure the directory exists
    await fs.promises.mkdir(dirPath, { recursive: true });

    // Create a write stream to save the file
    const writeStream = fs.createWriteStream(filePath);

    // Pipe the audio stream to the file and wait for it to finish
    await new Promise((resolve, reject) => {
      (audioStream as Writable).pipe(writeStream);
      writeStream.on('finish', resolve);
      writeStream.on('error', reject);
    });

    const publicUrl = `/audio/${fileName}`;
    console.log(`Audio file saved locally: ${filePath}`);
    console.log(`Public URL: ${publicUrl}`);

    return publicUrl;

  } catch (error) {
    console.error('Error generating voice from ElevenLabs:', error);
    throw new Error('Failed to generate and save voice.');
  }
}