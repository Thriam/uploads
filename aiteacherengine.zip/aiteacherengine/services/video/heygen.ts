import axios from 'axios';

const HEYGEN_API_URL = 'https://api.heygen.com/v1';
const POLLING_INTERVAL = 10000; // 10 seconds
const TIMEOUT = 300000; // 5 minutes

const heygenClient = axios.create({
  baseURL: HEYGEN_API_URL,
  headers: {
    'X-Api-Key': process.env.HEYGEN_API_KEY,
    'Content-Type': 'application/json',
  },
});

interface NewVideoResponse {
  data: {
    video_id: string;
  };
}

interface VideoStatusResponse {
  data: {
    status: 'pending' | 'processing' | 'completed' | 'failed';
    video_url?: string;
  };
}

/**
 * Generates an avatar video by sending a request to HeyGen and polling for the result.
 * @param script The script for the video.
 * @param voiceUrl The public URL of the voice audio file.
 * @param avatarId The ID of the HeyGen avatar to use.
 * @returns A promise that resolves to the final video URL.
 */
export async function generateAvatarVideo(script: string, voiceUrl: string, avatarId: string): Promise<string> {
  console.log('Starting HeyGen video generation...');
  
  // 1. Send generation request
  const videoId = await createVideoTask(script, voiceUrl, avatarId);
  console.log(`HeyGen video task created with ID: ${videoId}`);

  // 2. Poll for video status
  const videoUrl = await pollForVideo(videoId);
  console.log(`HeyGen video successfully generated: ${videoUrl}`);

  // 4. Return final video URL
  return videoUrl;
}

async function createVideoTask(script: string, voiceUrl: string, avatarId: string): Promise<string> {
  try {
    const response = await heygenClient.post<NewVideoResponse>('/video/generate', {
      video_inputs: [
        {
          character: {
            type: 'avatar',
            avatar_id: avatarId,
            avatar_style: 'normal',
          },
          voice: {
            type: 'audio',
            audio_url: voiceUrl,
          },
        },
      ],
      test: true,
      caption: true,
      dimension: {
        width: 1080,
        height: 1920,
      },
    });

    const videoId = response.data.data.video_id;
    if (!videoId) {
      throw new Error('HeyGen API did not return a video_id.');
    }
    return videoId;
  } catch (error) {
    console.error('Error creating HeyGen video task:', error.response?.data || error.message);
    throw new Error('Failed to initiate HeyGen video generation.');
  }
}

async function pollForVideo(videoId: string): Promise<string> {
  const startTime = Date.now();

  while (Date.now() - startTime < TIMEOUT) {
    await new Promise(resolve => setTimeout(resolve, POLLING_INTERVAL));
    console.log(`Polling for HeyGen video status (ID: ${videoId})...`);

    try {
      const response = await heygenClient.get<VideoStatusResponse>(`/video_status.get?video_id=${videoId}`);
      const { status, video_url } = response.data.data;

      console.log(`Current video status: ${status}`);

      if (status === 'completed') {
        if (!video_url) {
          throw new Error('HeyGen video completed but no URL was provided.');
        }
        return video_url;
      }

      if (status === 'failed') {
        throw new Error('HeyGen video generation failed.');
      }
      // If status is 'pending' or 'processing', the loop will continue.

    } catch (error) {
      // This catches errors in the polling request itself.
      // We log it but continue polling until the timeout.
      console.error('Error during polling attempt:', error.response?.data || error.message);
    }
  }

  throw new Error(`HeyGen video generation timed out after ${TIMEOUT / 1000 / 60} minutes.`);
}