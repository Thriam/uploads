import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface ScriptOutput {
  hook: string;
  script: string;
  caption: string;
}

/**
 * Generates a structured video script based on a topic and niche using OpenAI.
 * @param topic The topic for the video script.
 * @param niche The target niche for the content.
 * @param temperature The creativity of the response. Defaults to 0.7.
 * @returns A promise that resolves to an object containing the hook, script, and caption.
 */
export async function generateScript(
  topic: string,
  niche: string,
  temperature: number = 0.7
): Promise<ScriptOutput> {
  try {
    const prompt = `
      You are an expert scriptwriter for social media, specializing in educational content for Instagram Reels.
      Your task is to generate a complete script package for a 60-second talking-head video.

      **Topic:** "${topic}"
      **Niche:** "${niche}"

      **Instructions:**
      1.  **Hook (3 seconds):** Start with a very strong, attention-grabbing hook that creates curiosity or states a surprising fact.
      2.  **Script (50 seconds):** Write the main body of the script.
          - Use a conversational, friendly, and authoritative "teacher" tone.
          - Use short, simple sentences. The language should be easy to understand.
          - Structure the content to be highly engaging and optimized for audience retention.
          - Break down the topic into clear, digestible points.
      3.  **Call to Action (7 seconds):** End with a clear call to action (e.g., "Follow for more tips," "Comment your thoughts below").
      4.  **Caption:** Write a short, engaging caption for the Reel. Include 3-5 relevant hashtags.

      **Output Format:**
      Return the response as a structured JSON object with the following keys: "hook", "script", "caption".
    `;

    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo',
      messages: [{ role: 'user', content: prompt }],
      response_format: { type: 'json_object' },
      temperature: temperature,
      max_tokens: 1000,
    });

    const content = response.choices[0]?.message?.content;

    if (!content) {
      throw new Error('OpenAI returned an empty response.');
    }

    const parsedContent: ScriptOutput = JSON.parse(content);

    if (!parsedContent.hook || !parsedContent.script || !parsedContent.caption) {
      throw new Error('OpenAI response is missing required JSON fields.');
    }

    return parsedContent;
  } catch (error) {
    console.error('Error generating script from OpenAI:', error);
    if (error instanceof SyntaxError) {
      throw new Error('Failed to parse JSON response from OpenAI.');
    }
    throw new Error('Failed to generate video script.');
  }
}
