import axios from 'axios';

const META_GRAPH_API_URL = 'https://graph.facebook.com/v19.0';
const POLLING_INTERVAL = 10000; // 10 seconds
const TIMEOUT = 300000; // 5 minutes

interface MediaContainerResponse {
  id: string;
}

interface MediaStatusResponse {
  status_code: 'FINISHED' | 'IN_PROGRESS' | 'ERROR';
}

interface PublishResponse {
  id: string;
}

/**
 * Posts a video to an Instagram Business Account as a Reel.
 * @param videoUrl The public URL of the video file.
 * @param caption The caption for the Reel.
 * @returns A promise that resolves to the ID of the created post.
 */
export async function postToInstagram(videoUrl: string, caption: string): Promise<string> {
  const accountId = process.env.INSTAGRAM_BUSINESS_ACCOUNT_ID;
  const accessToken = process.env.META_ACCESS_TOKEN;

  if (!accountId || !accessToken) {
    throw new Error('Instagram Account ID or Meta Access Token is not configured in environment variables.');
  }

  try {
    // Step 1: Create a media container
    console.log('Step 1/3: Creating Instagram media container...');
    const containerResponse = await axios.post<MediaContainerResponse>(
      `${META_GRAPH_API_URL}/${accountId}/media`,
      {
        media_type: 'REELS',
        video_url: videoUrl,
        caption: caption,
        access_token: accessToken,
      }
    );
    const containerId = containerResponse.data.id;
    console.log(`Container created with ID: ${containerId}`);

    // Step 2: Poll for container status
    console.log('Step 2/3: Polling for container status...');
    const startTime = Date.now();
    while (Date.now() - startTime < TIMEOUT) {
      const statusResponse = await axios.get<MediaStatusResponse>(`${META_GRAPH_API_URL}/${containerId}`, {
        params: { fields: 'status_code', access_token: accessToken },
      });
      const status = statusResponse.data.status_code;
      console.log(`Container status: ${status}`);

      if (status === 'FINISHED') {
        // Step 3: Publish the media container
        console.log('Step 3/3: Publishing media container...');
        const publishResponse = await axios.post<PublishResponse>(
          `${META_GRAPH_API_URL}/${accountId}/media_publish`,
          { creation_id: containerId, access_token: accessToken }
        );
        console.log(`Successfully published to Instagram. Post ID: ${publishResponse.data.id}`);
        return publishResponse.data.id;
      }

      if (status === 'ERROR') {
        throw new Error('Instagram media container failed to process.');
      }

      await new Promise(resolve => setTimeout(resolve, POLLING_INTERVAL));
    }
    throw new Error('Instagram media container processing timed out.');

  } catch (error) {
    console.error('Error posting to Instagram:', error.response?.data || error.message);
    throw new Error('Failed to post video to Instagram.');
  }
}

/**
 * Posts a video to a Facebook Page.
 * @param videoUrl The public URL of the video file.
 * @param caption The caption/description for the video.
 * @returns A promise that resolves to the ID of the created post.
 */
export async function postToFacebook(videoUrl: string, caption: string): Promise<string> {
  const pageId = process.env.FACEBOOK_PAGE_ID;
  const accessToken = process.env.META_ACCESS_TOKEN;

  if (!pageId || !accessToken) {
    throw new Error('Facebook Page ID or Meta Access Token is not configured in environment variables.');
  }

  try {
    console.log('Posting video to Facebook Page...');
    const response = await axios.post<PublishResponse>(
      `${META_GRAPH_API_URL}/${pageId}/videos`,
      {
        file_url: videoUrl,
        description: caption,
        access_token: accessToken,
      }
    );
    console.log(`Successfully posted to Facebook. Post ID: ${response.data.id}`);
    return response.data.id;
  } catch (error) {
    console.error('Error posting to Facebook:', error.response?.data || error.message);
    throw new Error('Failed to post video to Facebook.');
  }
}