"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";

export default function DashboardPage() {
  // Mock data for demonstration
  const stats = {
    totalVideos: 24,
    completedVideos: 18,
    pendingVideos: 4,
    failedVideos: 2,
    totalViews: 15420,
    totalLikes: 3240,
  };

  const recentVideos = [
    { id: '1', topic: 'Introduction to Machine Learning', status: 'COMPLETED', views: 1200, likes: 340, date: '2024-01-15' },
    { id: '2', topic: 'Understanding Neural Networks', status: 'COMPLETED', views: 980, likes: 210, date: '2024-01-14' },
    { id: '3', topic: 'Python for Data Science', status: 'PROCESSING', views: 0, likes: 0, date: '2024-01-14' },
    { id: '4', topic: 'Deep Learning Basics', status: 'PENDING', views: 0, likes: 0, date: '2024-01-13' },
  ];

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'success';
      case 'PROCESSING':
        return 'processing';
      case 'PENDING':
        return 'warning';
      case 'FAILED':
        return 'destructive';
      default:
        return 'default';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard Overview</h2>
        <p className="text-muted-foreground">
          Welcome back! Here's an overview of your AI Teacher performance.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Videos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalVideos}</div>
            <p className="text-xs text-muted-foreground">
              All time
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Completed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.completedVideos}</div>
            <p className="text-xs text-muted-foreground">
              Successfully posted
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Views
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalViews.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Across all platforms
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Likes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalLikes.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Engagement metric
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Videos */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Videos</CardTitle>
          <CardDescription>
            Your latest video generation jobs.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentVideos.map((video) => (
              <div
                key={video.id}
                className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
              >
                <div className="space-y-1">
                  <p className="text-sm font-medium leading-none">
                    {video.topic}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {video.date}
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  {video.status === 'COMPLETED' && (
                    <div className="text-right">
                      <p className="text-sm font-medium">{video.views.toLocaleString()} views</p>
                      <p className="text-xs text-muted-foreground">{video.likes} likes</p>
                    </div>
                  )}
                  <Badge variant={getStatusVariant(video.status) as any}>
                    {video.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
