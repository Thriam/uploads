"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Badge } from "../../../components/ui/badge";

export default function AvatarsPage() {
  // Mock data for avatars
  const avatars = [
    { id: '1', name: 'Professional Woman', heygenId: 'avatar_001', status: 'active', thumbnail: '' },
    { id: '2', name: 'Professional Man', heygenId: 'avatar_002', status: 'active', thumbnail: '' },
    { id: '3', name: 'Casual Young Adult', heygenId: 'avatar_003', status: 'inactive', thumbnail: '' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Avatars</h2>
        <p className="text-muted-foreground">
          Manage your AI avatars for video generation.
        </p>
      </div>

      {/* Avatars Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {avatars.map((avatar) => (
          <Card key={avatar.id} className="overflow-hidden">
            <div className="aspect-[9/16] bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
              <span className="text-4xl">👤</span>
            </div>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{avatar.name}</CardTitle>
                <Badge variant={avatar.status === 'active' ? 'success' : 'secondary'}>
                  {avatar.status}
                </Badge>
              </div>
              <CardDescription>HeyGen ID: {avatar.heygenId}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  Edit
                </Button>
                <Button variant="default" size="sm" className="flex-1">
                  Set Active
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {/* Add New Avatar Card */}
        <Card className="border-dashed">
          <CardContent className="flex h-full min-h-[300px] items-center justify-center">
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800">
                <span className="text-2xl">+</span>
              </div>
              <p className="text-sm font-medium">Add New Avatar</p>
              <p className="text-xs text-muted-foreground mt-1">
                Connect to HeyGen to add more avatars
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
