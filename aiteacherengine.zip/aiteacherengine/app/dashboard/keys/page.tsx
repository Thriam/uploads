"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";

export default function APIKeysPage() {
  const [apiKeys, setApiKeys] = useState({
    openaiApiKey: "",
    elevenLabsApiKey: "",
    heygenApiKey: "",
    metaAccessToken: "",
  });
  const [isSaving, setIsSaving] = useState(false);
  const [showKeys, setShowKeys] = useState({
    openai: false,
    elevenlabs: false,
    heygen: false,
    meta: false,
  });

  const handleSave = async () => {
    setIsSaving(true);
    // In a real app, this would call an API to save encrypted keys
    setTimeout(() => {
      setIsSaving(false);
    }, 1000);
  };

  const toggleShowKey = (key: keyof typeof showKeys) => {
    setShowKeys({ ...showKeys, [key]: !showKeys[key] });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">API Keys</h2>
        <p className="text-muted-foreground">
          Manage your API keys for external services. Keys are encrypted for security.
        </p>
      </div>

      {/* OpenAI */}
      <Card>
        <CardHeader>
          <CardTitle>OpenAI</CardTitle>
          <CardDescription>
            Required for generating video scripts.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Label htmlFor="openai-api-key">API Key</Label>
          <div className="flex gap-2">
            <Input
              id="openai-api-key"
              type={showKeys.openai ? "text" : "password"}
              value={apiKeys.openaiApiKey}
              onChange={(e) => setApiKeys({ ...apiKeys, openaiApiKey: e.target.value })}
              placeholder="sk-..."
              className="flex-1"
            />
            <Button variant="outline" onClick={() => toggleShowKey('openai')}>
              {showKeys.openai ? "Hide" : "Show"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* ElevenLabs */}
      <Card>
        <CardHeader>
          <CardTitle>ElevenLabs</CardTitle>
          <CardDescription>
            Required for generating voice-overs.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Label htmlFor="elevenlabs-api-key">API Key</Label>
          <div className="flex gap-2">
            <Input
              id="elevenlabs-api-key"
              type={showKeys.elevenlabs ? "text" : "password"}
              value={apiKeys.elevenLabsApiKey}
              onChange={(e) => setApiKeys({ ...apiKeys, elevenLabsApiKey: e.target.value })}
              placeholder="..."
              className="flex-1"
            />
            <Button variant="outline" onClick={() => toggleShowKey('elevenlabs')}>
              {showKeys.elevenlabs ? "Hide" : "Show"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* HeyGen */}
      <Card>
        <CardHeader>
          <CardTitle>HeyGen</CardTitle>
          <CardDescription>
            Required for generating avatar videos.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Label htmlFor="heygen-api-key">API Key</Label>
          <div className="flex gap-2">
            <Input
              id="heygen-api-key"
              type={showKeys.heygen ? "text" : "password"}
              value={apiKeys.heygenApiKey}
              onChange={(e) => setApiKeys({ ...apiKeys, heygenApiKey: e.target.value })}
              placeholder="..."
              className="flex-1"
            />
            <Button variant="outline" onClick={() => toggleShowKey('heygen')}>
              {showKeys.heygen ? "Hide" : "Show"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Meta */}
      <Card>
        <CardHeader>
          <CardTitle>Meta (Facebook/Instagram)</CardTitle>
          <CardDescription>
            Required for posting videos to social media.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Label htmlFor="meta-access-token">Access Token</Label>
          <div className="flex gap-2">
            <Input
              id="meta-access-token"
              type={showKeys.meta ? "text" : "password"}
              value={apiKeys.metaAccessToken}
              onChange={(e) => setApiKeys({ ...apiKeys, metaAccessToken: e.target.value })}
              placeholder="..."
              className="flex-1"
            />
            <Button variant="outline" onClick={() => toggleShowKey('meta')}>
              {showKeys.meta ? "Hide" : "Show"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? "Saving..." : "Save API Keys"}
        </Button>
      </div>
    </div>
  );
}
