"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import { Switch } from "../../../components/ui/switch";

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    dailyPostTime: "10:00",
    topicCategory: "General Knowledge",
    autoPost: false,
    avatarPhotoUrl: "",
    heygenAvatarId: "",
  });
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    // In a real app, this would call an API to save settings
    setTimeout(() => {
      setIsSaving(false);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
        <p className="text-muted-foreground">
          Configure your AI Teacher preferences and automation settings.
        </p>
      </div>

      {/* Automation Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Automation Settings</CardTitle>
          <CardDescription>
            Configure automatic video generation and posting.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="auto-post">Auto Post</Label>
              <p className="text-sm text-muted-foreground">
                Automatically post videos to social media when ready.
              </p>
            </div>
            <Switch
              id="auto-post"
              checked={settings.autoPost}
              onCheckedChange={(checked: boolean) => setSettings({ ...settings, autoPost: checked })}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="post-time">Daily Post Time (UTC)</Label>
            <Input
              id="post-time"
              type="time"
              value={settings.dailyPostTime}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSettings({ ...settings, dailyPostTime: e.target.value })}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="topic-category">Topic Category</Label>
            <Input
              id="topic-category"
              value={settings.topicCategory}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSettings({ ...settings, topicCategory: e.target.value })}
              placeholder="e.g., General Knowledge, Tech, Science"
            />
          </div>
        </CardContent>
      </Card>

      {/* Avatar Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Avatar Settings</CardTitle>
          <CardDescription>
            Configure your AI avatar for video generation.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="heygen-avatar-id">HeyGen Avatar ID</Label>
            <Input
              id="heygen-avatar-id"
              value={settings.heygenAvatarId}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSettings({ ...settings, heygenAvatarId: e.target.value })}
              placeholder="Enter your HeyGen avatar ID"
            />
            <p className="text-xs text-muted-foreground">
              Find your avatar ID in your HeyGen dashboard.
            </p>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="avatar-photo">Avatar Photo URL</Label>
            <Input
              id="avatar-photo"
              value={settings.avatarPhotoUrl}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSettings({ ...settings, avatarPhotoUrl: e.target.value })}
              placeholder="https://..."
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? "Saving..." : "Save Settings"}
        </Button>
      </div>
    </div>
  );
}
