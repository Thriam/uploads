"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Badge } from "../../../components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../../components/ui/table";

export default function VideosPage() {
  const [topic, setTopic] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  // Mock data
  const videos = [
    { id: '1', topic: 'Introduction to Machine Learning', status: 'COMPLETED', views: 1200, likes: 340, date: '2024-01-15' },
    { id: '2', topic: 'Understanding Neural Networks', status: 'COMPLETED', views: 980, likes: 210, date: '2024-01-14' },
    { id: '3', topic: 'Python for Data Science', status: 'GENERATING_VIDEO', views: 0, likes: 0, date: '2024-01-14' },
    { id: '4', topic: 'Deep Learning Basics', status: 'GENERATING_SCRIPT', views: 0, likes: 0, date: '2024-01-13' },
    { id: '5', topic: 'AI Ethics', status: 'PENDING', views: 0, likes: 0, date: '2024-01-12' },
    { id: '6', topic: 'Computer Vision Fundamentals', status: 'FAILED', views: 0, likes: 0, date: '2024-01-11', error: 'API limit exceeded' },
  ];

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'success';
      case 'GENERATING_VIDEO':
      case 'GENERATING_SCRIPT':
      case 'GENERATING_VOICE':
        return 'processing';
      case 'PENDING':
        return 'warning';
      case 'FAILED':
        return 'destructive';
      default:
        return 'default';
    }
  };

  const handleGenerateVideo = async () => {
    if (!topic.trim()) return;
    setIsGenerating(true);
    // In a real app, this would call an API to create a video job
    setTimeout(() => {
      setIsGenerating(false);
      setTopic("");
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Videos</h2>
        <p className="text-muted-foreground">
          Generate and manage your AI-powered educational videos.
        </p>
      </div>

      {/* Generate New Video */}
      <Card>
        <CardHeader>
          <CardTitle>Generate New Video</CardTitle>
          <CardDescription>
            Enter a topic and our AI will create a script, generate voice, and produce a video.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              placeholder="Enter video topic (e.g., Introduction to Python)"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="flex-1"
            />
            <Button onClick={handleGenerateVideo} disabled={isGenerating || !topic.trim()}>
              {isGenerating ? "Generating..." : "Generate Video"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Videos Table */}
      <Card>
        <CardHeader>
          <CardTitle>Video History</CardTitle>
          <CardDescription>
            View all your generated videos and their status.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Topic</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Views</TableHead>
                <TableHead>Likes</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {videos.map((video) => (
                <TableRow key={video.id}>
                  <TableCell className="font-medium">{video.topic}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(video.status) as any}>
                      {video.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{video.views > 0 ? video.views.toLocaleString() : '-'}</TableCell>
                  <TableCell>{video.likes > 0 ? video.likes.toLocaleString() : '-'}</TableCell>
                  <TableCell>{video.date}</TableCell>
                  <TableCell className="text-right">
                    {video.status === 'COMPLETED' && (
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    )}
                    {video.status === 'FAILED' && video.error && (
                      <span className="text-xs text-red-500">{video.error}</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
