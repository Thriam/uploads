package com.tnc.service;

import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class MarketDataService {
    
    private final Map<String, StockData> stockDatabase = new ConcurrentHashMap<>();
    
    public MarketDataService() {
        // Initialize with some sample stock data
        stockDatabase.put("AAPL", new StockData("AAPL", "Apple Inc.", 175.0, 2800000000000L, 28.5, 195.0, 150.0, 0.45));
        stockDatabase.put("GOOGL", new StockData("GOOGL", "Alphabet Inc.", 2850.0, 1800000000000L, 25.0, 3000.0, 2500.0, 0.0));
        stockDatabase.put("MSFT", new StockData("MSFT", "Microsoft Corporation", 350.0, 2600000000000L, 30.0, 380.0, 280.0, 0.8));
        stockDatabase.put("TSLA", new StockData("TSLA", "Tesla Inc.", 200.0, 630000000000L, 50.0, 300.0, 150.0, 0.0));
        stockDatabase.put("AMZN", new StockData("AMZN", "Amazon.com Inc.", 3300.0, 1700000000000L, 60.0, 3800.0, 2800.0, 0.0));
        stockDatabase.put("NVDA", new StockData("NVDA", "NVIDIA Corporation", 450.0, 1100000000000L, 65.0, 500.0, 350.0, 0.03));
        stockDatabase.put("META", new StockData("META", "Meta Platforms Inc.", 320.0, 820000000000L, 20.0, 380.0, 250.0, 0.0));
        stockDatabase.put("NFLX", new StockData("NFLX", "Netflix Inc.", 400.0, 180000000000L, 40.0, 450.0, 300.0, 0.0));
    }
    
    public StockData getStockPrice(String symbol) {
        // Add some random variation to simulate price changes
        StockData base = stockDatabase.get(symbol.toUpperCase());
        if (base == null) {
            return null;
        }
        double variation = (Math.random() - 0.5) * 0.02; // +/- 1% variation
        double newPrice = base.getPrice() * (1 + variation);
        double change = newPrice - base.getPrice();
        double changePercent = (change / base.getPrice()) * 100;
        
        return new StockData(
            symbol.toUpperCase(),
            base.getName(),
            Math.round(newPrice * 100.0) / 100.0,
            base.getMarketCap(),
            base.getPeRatio(),
            base.getWeek52High(),
            base.getWeek52Low(),
            base.getDividendYield()
        );
    }
    
    public StockData getStockInfo(String symbol) {
        return stockDatabase.get(symbol.toUpperCase());
    }
    
    public static class StockData {
        private String symbol;
        private String name;
        private double price;
        private long marketCap;
        private double peRatio;
        private double week52High;
        private double week52Low;
        private double dividendYield;
        
        public StockData(String symbol, String name, double price, long marketCap, 
                        double peRatio, double week52High, double week52Low, double dividendYield) {
            this.symbol = symbol;
            this.name = name;
            this.price = price;
            this.marketCap = marketCap;
            this.peRatio = peRatio;
            this.week52High = week52High;
            this.week52Low = week52Low;
            this.dividendYield = dividendYield;
        }
        
        // Getters
        public String getSymbol() { return symbol; }
        public String getName() { return name; }
        public double getPrice() { return price; }
        public long getMarketCap() { return marketCap; }
        public double getPeRatio() { return peRatio; }
        public double getWeek52High() { return week52High; }
        public double getWeek52Low() { return week52Low; }
        public double getDividendYield() { return dividendYield; }
    }
}
