package com.tnc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SwaggerController {

    @GetMapping("/docs")
    public String redirectToSwagger() {
        return "forward:/swagger-ui.html";
    }
}
